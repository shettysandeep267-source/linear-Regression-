import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

# 1. Load data from the CSV file
df = pd.read_csv("financial_loss_data.csv")

# 2. Separate features (input) and target (output)
X = df[["downtime_hours", "affected_customers", "records_exposed",
        "response_cost_usd", "business_criticality"]]
y = df["Target_Financial_Loss_USD"]

# 3. Split data into training (80%) and testing (20%) sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 4. Initialize and train the Linear Regression model
model = LinearRegression()
model.fit(X_train, y_train)

# 5. Predict on test data and a custom incident example
y_pred = model.predict(X_test)
sample_input = pd.DataFrame([{
    "downtime_hours": 12, "affected_customers": 5000,
    "records_exposed": 2000, "response_cost_usd": 25000,
    "business_criticality": 4
}])
custom_pred = model.predict(sample_input)

# 6. Display results
print("Mean Absolute Error:", round(mean_absolute_error(y_test, y_pred), 2), "USD")
print("R-squared Score:", round(r2_score(y_test, y_pred), 3))
print("First 5 Test Predictions:", y_pred[:5].round(2))
print("Estimated Financial Loss: $", round(max(0, float(custom_pred[0])), 2))
