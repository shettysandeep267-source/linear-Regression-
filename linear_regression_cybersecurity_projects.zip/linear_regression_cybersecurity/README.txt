# Linear Regression Cybersecurity Mini-Projects

Three educational projects using the same six-step Linear Regression workflow:
1. Vulnerability risk score estimation
2. Incident recovery time estimation
3. Cybersecurity incident financial loss estimation

## Install
    pip install pandas scikit-learn

## Run
Run each script from this folder so its matching CSV can be found:
    python vulnerability_risk_score.py
    python incident_recovery_time.py
    python financial_loss_estimation.py

## Dataset files
- vulnerability_risk_data.csv
- recovery_time_data.csv
- financial_loss_data.csv

## Important
All CSV datasets are synthetic and generated for learning. They are not real incident records and must not be used for operational risk decisions, regulatory reporting, insurance claims, or financial forecasts.
The risk score is a teaching example, not an official CVSS score. Recovery time and financial loss depend on many organization-specific factors not represented here.
Mean Absolute Error (MAE) reports average prediction error in the target's units. R-squared describes fit on the test sample and is not a guarantee of future accuracy.
